# Alien Adventure

This repository is for the Alien Adventure app for Udacity's Beginning iOS App Development.

###Maintainers

@jarrodparkes

###How To Contribute

- Fork the repository to your personal account
- Make your changes
- Submit a pull request to this repository

###Description

To finish an intergalactic journey, a hero needs your help answering the tricky requests of aliens.
